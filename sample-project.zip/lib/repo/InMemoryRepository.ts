import type { IDataRepository } from "./IDataRepository"
import type {
  Product,
  Category,
  Service,
  Enquiry,
  HomePageContent,
  AboutPageContent,
  ContactPageContent,
  FooterContent,
} from "@/types"
import { seedProducts, seedCategories, seedServices } from "./seed-data"
import { seedHomePageContent, seedAboutPageContent, seedContactPageContent, seedFooterContent } from "./seed-content"

class InMemoryRepository implements IDataRepository {
  private products: Map<string, Product> = new Map()
  private categories: Map<string, Category> = new Map()
  private services: Map<string, Service> = new Map()
  private enquiries: Map<string, Enquiry> = new Map()
  private homePageContent: HomePageContent
  private aboutPageContent: AboutPageContent
  private contactPageContent: ContactPageContent
  private footerContent: FooterContent

  constructor() {
    this.initializeData()
    this.homePageContent = seedHomePageContent
    this.aboutPageContent = seedAboutPageContent
    this.contactPageContent = seedContactPageContent
    this.footerContent = seedFooterContent
  }

  private initializeData() {
    seedProducts.forEach((product) => this.products.set(product.id, product))
    seedCategories.forEach((category) => this.categories.set(category.id, category))
    seedServices.forEach((service) => this.services.set(service.id, service))
  }

  // Products
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values())
  }

  async getProductById(id: string): Promise<Product | null> {
    return this.products.get(id) || null
  }

  async getProductBySlug(slug: string): Promise<Product | null> {
    return Array.from(this.products.values()).find((p) => p.slug === slug) || null
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter((p) => p.category === category)
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowerQuery = query.toLowerCase()
    return Array.from(this.products.values()).filter(
      (p) =>
        p.name.toLowerCase().includes(lowerQuery) ||
        p.casNumber.includes(query) ||
        p.hsCode?.includes(query) ||
        p.description.toLowerCase().includes(lowerQuery),
    )
  }

  async createProduct(productData: Omit<Product, "id" | "createdAt" | "updatedAt">): Promise<Product> {
    const product: Product = {
      ...productData,
      id: `prod_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.products.set(product.id, product)
    return product
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product | null> {
    const product = this.products.get(id)
    if (!product) return null

    const updated = { ...product, ...updates, updatedAt: new Date() }
    this.products.set(id, updated)
    return updated
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id)
  }

  // Categories
  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values())
  }

  async getCategoryById(id: string): Promise<Category | null> {
    return this.categories.get(id) || null
  }

  async createCategory(categoryData: Omit<Category, "id">): Promise<Category> {
    const category: Category = {
      ...categoryData,
      id: `cat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    }
    this.categories.set(category.id, category)
    return category
  }

  async updateCategory(id: string, updates: Partial<Category>): Promise<Category | null> {
    const category = this.categories.get(id)
    if (!category) return null

    const updated = { ...category, ...updates }
    this.categories.set(id, updated)
    return updated
  }

  async deleteCategory(id: string): Promise<boolean> {
    return this.categories.delete(id)
  }

  // Services
  async getAllServices(): Promise<Service[]> {
    return Array.from(this.services.values())
  }

  async getServiceById(id: string): Promise<Service | null> {
    return this.services.get(id) || null
  }

  async getServiceBySlug(slug: string): Promise<Service | null> {
    return Array.from(this.services.values()).find((s) => s.slug === slug) || null
  }

  // Enquiries
  async createEnquiry(enquiryData: Omit<Enquiry, "id" | "createdAt" | "updatedAt">): Promise<Enquiry> {
    const enquiry: Enquiry = {
      ...enquiryData,
      id: `enq_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.enquiries.set(enquiry.id, enquiry)
    return enquiry
  }

  async getAllEnquiries(): Promise<Enquiry[]> {
    return Array.from(this.enquiries.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    )
  }

  async getEnquiryById(id: string): Promise<Enquiry | null> {
    return this.enquiries.get(id) || null
  }

  async updateEnquiryStatus(id: string, status: "pending" | "contacted" | "resolved"): Promise<Enquiry | null> {
    const enquiry = this.enquiries.get(id)
    if (!enquiry) return null

    const updated = { ...enquiry, status, updatedAt: new Date() }
    this.enquiries.set(id, updated)
    return updated
  }

  // CMS content management methods
  async getHomePageContent(): Promise<HomePageContent> {
    return this.homePageContent
  }

  async updateHomePageContent(updates: Partial<HomePageContent>): Promise<HomePageContent> {
    this.homePageContent = {
      ...this.homePageContent,
      ...updates,
      updatedAt: new Date(),
    }
    return this.homePageContent
  }

  async getAboutPageContent(): Promise<AboutPageContent> {
    return this.aboutPageContent
  }

  async updateAboutPageContent(updates: Partial<AboutPageContent>): Promise<AboutPageContent> {
    this.aboutPageContent = {
      ...this.aboutPageContent,
      ...updates,
      updatedAt: new Date(),
    }
    return this.aboutPageContent
  }

  async getContactPageContent(): Promise<ContactPageContent> {
    return this.contactPageContent
  }

  async updateContactPageContent(updates: Partial<ContactPageContent>): Promise<ContactPageContent> {
    this.contactPageContent = {
      ...this.contactPageContent,
      ...updates,
      updatedAt: new Date(),
    }
    return this.contactPageContent
  }

  async getFooterContent(): Promise<FooterContent> {
    return this.footerContent
  }

  async updateFooterContent(updates: Partial<FooterContent>): Promise<FooterContent> {
    this.footerContent = {
      ...this.footerContent,
      ...updates,
      updatedAt: new Date(),
    }
    return this.footerContent
  }
}

// Singleton instance
let repositoryInstance: InMemoryRepository | null = null

export function getRepository(): IDataRepository {
  if (!repositoryInstance) {
    repositoryInstance = new InMemoryRepository()
  }
  return repositoryInstance
}

export { InMemoryRepository }
