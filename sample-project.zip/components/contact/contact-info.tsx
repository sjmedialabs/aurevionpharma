"use client"

import Image from "next/image"
import { Mail } from "lucide-react"
import { useEffect, useState } from "react"
import type { ContactPageContent } from "@/types"

export function ContactInfo() {
  const [content, setContent] = useState<ContactPageContent["contactInfo"] | null>(null)

  useEffect(() => {
    fetch("/api/content/contact")
      .then((res) => res.json())
      .then((data: ContactPageContent) => setContent(data.contactInfo))
      .catch((error) => console.error("Failed to fetch contact info:", error))
  }, [])

  if (!content) {
    return (
      <div className="space-y-10">
        <div className="h-32 bg-gray-200 animate-pulse rounded" />
        <div className="space-y-8">
          <div className="h-24 bg-gray-200 animate-pulse rounded" />
          <div className="h-24 bg-gray-200 animate-pulse rounded" />
          <div className="h-24 bg-gray-200 animate-pulse rounded" />
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-10">
      <div>
        <h2 className="mb-3 font-sans text-4xl font-bold text-gray-900">We'd love to hear from you</h2>
        <p className="font-sans text-base text-gray-600">Need something cleared up? Please contact our team</p>
      </div>

      <div className="space-y-8">
        {/* Email */}
        <div className="flex items-start gap-5">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-green-100">
            <Mail className="h-7 w-7 text-green-600" />
          </div>
          <div>
            <h3 className="mb-2 font-sans text-xl font-semibold text-gray-900">{content.email.title}</h3>
            <p className="mb-2 font-sans text-base text-gray-600">{content.email.description}</p>
            <a
              href={`mailto:${content.email.value}`}
              className="font-sans text-base font-medium text-[#4384C5] hover:underline"
            >
              {content.email.value}
            </a>
          </div>
        </div>

        {/* Phone */}
        <div className="flex items-start gap-5">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-blue-100">
            <Image src="/images/icons/phone-icon.png" alt="Phone" width={28} height={28} />
          </div>
          <div>
            <h3 className="mb-2 font-sans text-xl font-semibold text-gray-900">{content.phone.title}</h3>
            <p className="mb-2 font-sans text-base text-gray-600">{content.phone.description}</p>
            <a
              href={`tel:${content.phone.value.replace(/\s/g, "")}`}
              className="font-sans text-base font-medium text-[#4384C5] hover:underline"
            >
              {content.phone.value}
            </a>
          </div>
        </div>

        {/* Office */}
        <div className="flex items-start gap-5">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-orange-100">
            <Image src="/images/icons/location-icon.png" alt="Location" width={28} height={28} />
          </div>
          <div>
            <h3 className="mb-2 font-sans text-xl font-semibold text-gray-900">{content.office.title}</h3>
            <p className="font-sans text-base leading-relaxed text-gray-600 whitespace-pre-line">
              {content.office.address}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
