"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { LayoutDashboard, Package, FolderTree, Mail, LogOut, Beaker, Briefcase, FileText, Layers } from "lucide-react"
import { ThemeToggle } from "./theme-toggle"

const navigation = [
  { name: "Dashboard", href: "/admin", icon: LayoutDashboard },
  { name: "Products", href: "/admin/products", icon: Package },
  { name: "Categories", href: "/admin/categories", icon: FolderTree },
  { name: "Subcategories", href: "/admin/subcategories", icon: Layers },
  { name: "Services", href: "/admin/services", icon: Briefcase },
  { name: "Enquiries", href: "/admin/enquiries", icon: Mail },
  { name: "Content", href: "/admin/content", icon: FileText },
]

export function AdminSidebar() {
  const pathname = usePathname()
  const router = useRouter()

  const handleLogout = async () => {
    await fetch("/api/admin/logout", { method: "POST" })
    router.push("/admin/login")
    router.refresh()
  }

  return (
    <div className="flex h-full w-64 flex-col bg-white border-r border-gray-200 text-gray-900 dark:bg-gray-950 dark:border-gray-800 dark:text-white">
      <div className="flex h-16 items-center gap-2 border-b border-gray-200 dark:border-gray-800 px-6">
        <Beaker className="h-6 w-6 text-blue-600 dark:text-blue-400" />
        <div>
          <h1 className="text-lg font-bold text-gray-900 dark:text-white">Aurevion</h1>
          <p className="text-xs text-gray-500 dark:text-gray-400">Admin CMS</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3 py-4">
        {navigation.map((item) => {
          const isActive = pathname === item.href
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                isActive 
                  ? "bg-blue-50 text-blue-700 dark:bg-gray-800 dark:text-white" 
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white",
              )}
            >
              <item.icon className="h-5 w-5" />
              {item.name}
            </Link>
          )
        })}
      </nav>

      <div className="border-t border-gray-200 dark:border-gray-800 p-4 space-y-2">
        <ThemeToggle />
        <Button
          variant="ghost"
          className="w-full justify-start text-gray-600 hover:bg-gray-50 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800 dark:hover:text-white"
          onClick={handleLogout}
        >
          <LogOut className="mr-3 h-5 w-5" />
          Logout
        </Button>
      </div>
    </div>
  )
}
