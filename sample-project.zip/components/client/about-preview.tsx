"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { useEffect, useState } from "react"
import type { HomePageContent } from "@/types"

export function AboutPreview() {
  const [content, setContent] = useState<HomePageContent["aboutPreview"] | null>(null)

  useEffect(() => {
    fetch("/api/content/home")
      .then((res) => res.json())
      .then((data: HomePageContent) => setContent(data.aboutPreview))
      .catch((error) => console.error("Failed to fetch about preview:", error))
  }, [])

  if (!content) {
    return (
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="h-96 bg-gray-200 animate-pulse rounded-2xl" />
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 lg:grid-cols-[1fr_auto_1.2fr] lg:gap-12 items-center">
          {/* Left Column - Images */}
          <div className="grid grid-cols-1 gap-4">
            <div className="bg-gradient-to-br from-[#4384C5] to-[#0984E3] rounded-2xl p-8 aspect-square flex flex-col justify-center">
              <p className="text-white/80 text-sm font-light mb-4 uppercase tracking-wider">{content.badge}</p>
              <h3 className="text-white text-2xl font-light leading-relaxed">
                Breakthrough technologies
                <br />
                driving drug discovery
              </h3>
            </div>

            <div className="rounded-2xl overflow-hidden w-full aspect-[16/9]">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2020-SwmDIDwrvOzxl00nSBEaBj3jPkAvy9.png"
                alt="Laboratory Research with Microscope"
                width={800}
                height={450}
                className="h-full w-full object-cover"
              />
            </div>
          </div>

          {/* Center Column - DNA Helix Image */}
          <div className="flex justify-center lg:justify-start">
            <div className="w-64 h-64 rounded-full overflow-hidden flex-shrink-0">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image%2019-TACoWOiEl7OsrDgrlkvxO40JoZmRFk.png"
                alt="DNA Helix in Petri Dish"
                width={256}
                height={256}
                className="h-full w-full object-cover"
              />
            </div>
          </div>

          {/* Right Column - Content */}
          <div className="space-y-6">
            <h2 className="font-bold text-[32px] leading-tight" style={{ color: "#414881" }}>
              ABOUT US
            </h2>

            <h3 className="font-light text-[36px] leading-tight" style={{ color: "#4384C5" }}>
              {content.title}
            </h3>

            <p className="text-[14px] leading-relaxed" style={{ color: "#000" }}>
              {content.description}
            </p>

            {/* Features list */}
            <div className="space-y-4 pt-2">
              {content.features.map((feature) => (
                <div key={feature.title} className="flex gap-3">
                  <span className="text-2xl flex-shrink-0" style={{ color: "#4384C5" }}>
                    {feature.icon}
                  </span>
                  <div>
                    <h4 className="font-semibold text-[16px] mb-1" style={{ color: "#000" }}>
                      {feature.title}
                    </h4>
                    <p className="text-[14px] leading-relaxed" style={{ color: "#666" }}>
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Buttons */}
            <div className="flex gap-4 pt-4">
              <Button
                asChild
                className="rounded-full px-8 text-white hover:bg-[#2d5a8f]"
                style={{ backgroundColor: "#414881" }}
              >
                <Link href="/about">{content.primaryButtonText}</Link>
              </Button>
              <Button
                asChild
                className="rounded-full px-8 text-white hover:bg-[#2d6ba8]"
                style={{ backgroundColor: "#4384C5" }}
              >
                <Link href="/contact">{content.secondaryButtonText}</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
