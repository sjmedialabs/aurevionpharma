"use client"

import type React from "react"
import Link from "next/link"
import Image from "next/image"
import { Facebook, Linkedin, Youtube, ArrowRight, ChevronUp } from "lucide-react"
import { useState, useEffect } from "react"
import type { FooterContent } from "@/types"

const XIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
  </svg>
)

export function Footer() {
  const [email, setEmail] = useState("")
  const [content, setContent] = useState<FooterContent | null>(null)

  useEffect(() => {
    fetch("/api/content/footer")
      .then((res) => res.json())
      .then((data: FooterContent) => setContent(data))
      .catch((error) => console.error("Failed to fetch footer content:", error))
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Newsletter subscription:", email)
    setEmail("")
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  if (!content) {
    return (
      <footer className="bg-[#0f1f3d] text-white relative">
        <div className="container mx-auto px-4 py-16">
          <div className="h-64 bg-gray-700 animate-pulse rounded" />
        </div>
      </footer>
    )
  }

  return (
    <footer className="bg-[#0f1f3d] text-white relative">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid gap-12 lg:grid-cols-[1fr_2fr_1.5fr]">
          {/* Logo Section */}
          <div>
            <Link href="/" className="inline-block">
              <Image
                src={content.logo || "/placeholder.svg"}
                alt="Aurevion Pharmaceutical"
                width={280}
                height={80}
                className="h-auto w-auto max-w-[280px]"
              />
            </Link>
          </div>

          {/* Navigation Links */}
          <div className="grid grid-cols-2 gap-8">
            {/* Products Column */}
            <div>
              <ul className="space-y-3">
                {content.productLinks.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-base text-white hover:text-[#4384C5] transition-colors font-light"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* About Us Column */}
            <div>
              <ul className="space-y-3">
                {content.aboutLinks.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-base text-white hover:text-[#4384C5] transition-colors font-light"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>

              {/* Social Media Links */}
              <div className="mt-8">
                <p className="text-base text-white mb-4 font-light">Follow Us</p>
                <div className="flex gap-4">
                  {content.socialMedia.facebook && (
                    <a
                      href={content.socialMedia.facebook}
                      className="text-white hover:text-[#4384C5] transition-colors"
                      aria-label="Facebook"
                    >
                      <Facebook className="h-5 w-5" />
                    </a>
                  )}
                  {content.socialMedia.twitter && (
                    <a
                      href={content.socialMedia.twitter}
                      className="text-white hover:text-[#4384C5] transition-colors"
                      aria-label="X (Twitter)"
                    >
                      <XIcon className="h-5 w-5" />
                    </a>
                  )}
                  {content.socialMedia.youtube && (
                    <a
                      href={content.socialMedia.youtube}
                      className="text-white hover:text-[#4384C5] transition-colors"
                      aria-label="YouTube"
                    >
                      <Youtube className="h-5 w-5" />
                    </a>
                  )}
                  {content.socialMedia.linkedin && (
                    <a
                      href={content.socialMedia.linkedin}
                      className="text-white hover:text-[#4384C5] transition-colors"
                      aria-label="LinkedIn"
                    >
                      <Linkedin className="h-5 w-5" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Newsletter Section */}
          <div>
            <h3 className="text-2xl font-light text-white mb-6 leading-relaxed">{content.newsletter.heading}</h3>
            <form onSubmit={handleSubmit} className="flex gap-0">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={content.newsletter.placeholder}
                className="flex-1 px-6 py-3 bg-[#1a3a5c] text-white placeholder:text-gray-400 border-none outline-none text-sm"
                required
              />
              <button
                type="submit"
                className="bg-white text-[#0f1f3d] px-6 py-3 hover:bg-gray-100 transition-colors"
                aria-label="Subscribe"
              >
                <ArrowRight className="h-5 w-5" />
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="bg-[#0a1628] relative overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px)",
              backgroundSize: "50px 50px",
            }}
          />
        </div>

        <div className="container mx-auto px-4 py-6 relative">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6 text-sm">
            <p className="text-[#8893B9]">{content.contact.location}</p>
            <p className="text-[#8893B9]">{content.contact.phone}</p>
            <p className="text-[#8893B9]">{content.contact.email}</p>
            <p className="text-[#8893B9]" dangerouslySetInnerHTML={{ __html: content.copyright }} />
          </div>
        </div>
      </div>

      {/* Scroll to Top Button */}
      <button
        onClick={scrollToTop}
        className="fixed left-8 bottom-8 bg-[#4dd0e1] hover:bg-[#26c6da] text-white rounded-full p-3 transition-colors shadow-lg z-50"
        aria-label="Scroll to top"
      >
        <ChevronUp className="h-5 w-5" />
      </button>
    </footer>
  )
}
