"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, X, ChevronDown, ChevronRight } from "lucide-react"
import { useState, useEffect } from "react"
import Image from "next/image"
import { EnquiryModal } from "@/components/products/enquiry-modal"
import type { Category, SubCategory, Service } from "@/types"

const baseNavigation = [
  { name: "Home", href: "/" },
  { name: "About Us", href: "/about" },
]

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [categories, setCategories] = useState<Category[]>([])
  const [subcategories, setSubcategories] = useState<SubCategory[]>([])
  const [services, setServices] = useState<Service[]>([])
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null)
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set())
  const pathname = usePathname()
  const [isEnquiryModalOpen, setIsEnquiryModalOpen] = useState(false)

  useEffect(() => {
    fetchCategories()
    fetchSubcategories()
    fetchServices()
  }, [])

  const fetchCategories = async () => {
    try {
      const response = await fetch("/api/categories")
      if (response.ok) {
        const data = await response.json()
        setCategories(data)
      }
    } catch (error) {
      console.error("Error fetching categories:", error)
    }
  }

  const fetchSubcategories = async () => {
    try {
      const response = await fetch("/api/subcategories")
      if (response.ok) {
        const data = await response.json()
        setSubcategories(data)
      }
    } catch (error) {
      console.error("Error fetching subcategories:", error)
    }
  }

  const fetchServices = async () => {
    try {
      const response = await fetch("/api/services")
      if (response.ok) {
        const data = await response.json()
        setServices(data)
      }
    } catch (error) {
      console.error("Error fetching services:", error)
    }
  }

  const getSubcategoriesForCategory = (categoryId: string) => {
    return subcategories.filter(sub => sub.categoryId === categoryId)
  }

  const handleDropdownToggle = (dropdown: string) => {
    setActiveDropdown(activeDropdown === dropdown ? null : dropdown)
    // Reset expanded categories when closing dropdown
    if (activeDropdown === dropdown) {
      setExpandedCategories(new Set())
    }
  }

  const handleCategoryToggle = (categoryId: string, e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    
    const newExpanded = new Set(expandedCategories)
    if (expandedCategories.has(categoryId)) {
      newExpanded.delete(categoryId)
    } else {
      newExpanded.add(categoryId)
    }
    setExpandedCategories(newExpanded)
  }

  const handleCategoryNavigation = (categorySlug: string, e: React.MouseEvent) => {
    // Only navigate if it's a double-click or if the user holds Ctrl/Cmd
    if (e.detail === 2 || e.ctrlKey || e.metaKey) {
      e.preventDefault()
      window.open(`/products?category=${categorySlug}`, e.ctrlKey || e.metaKey ? '_blank' : '_self')
      closeDropdowns()
    }
  }

  const closeDropdowns = () => {
    setActiveDropdown(null)
    setExpandedCategories(new Set())
  }

  return (
    <>
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <nav className="container mx-auto px-4">
          <div className="flex h-24 items-center justify-between">
            <Link href="/" className="flex items-center">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AUREVION-PHARMA-LOGO-original-wWP2iaSaGxp7DpW3TLlb0sTnTqTdst.png"
                alt="Aurevion Pharmaceutical"
                width={300}
                height={90}
                className="h-[90px] w-auto"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex md:items-center md:gap-8">
              {baseNavigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`text-lg font-medium text-gray-700 hover:text-primary transition-colors relative pb-1 ${
                      isActive
                        ? "after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-red-600"
                        : ""
                    }`}
                    onClick={closeDropdowns}
                  >
                    {item.name}
                  </Link>
                )
              })}

              {/* Services Dropdown */}
              <div className="relative">
                <button
                  className={`flex items-center gap-1 text-lg font-medium text-gray-700 hover:text-primary transition-colors relative pb-1 ${
                    pathname.startsWith('/services')
                      ? "after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-red-600"
                      : ""
                  }`}
                  onClick={() => handleDropdownToggle('services')}
                  onMouseEnter={() => setActiveDropdown('services')}
                >
                  Services
                  <ChevronDown className="h-4 w-4" />
                </button>
                
                {activeDropdown === 'services' && (
                  <div 
                    className="absolute top-full left-0 mt-1 w-64 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50"
                    onMouseLeave={() => setActiveDropdown(null)}
                  >
                    <Link
                      href="/services"
                      className="block px-4 py-2 text-gray-700 hover:bg-gray-50 hover:text-primary transition-colors"
                      onClick={closeDropdowns}
                    >
                      All Services
                    </Link>
                    <hr className="my-2" />
                    {services.map((service) => (
                      <Link
                        key={service.id}
                        href={`/services#${service.slug}`}
                        className="block px-4 py-2 text-gray-700 hover:bg-gray-50 hover:text-primary transition-colors"
                        onClick={closeDropdowns}
                      >
                        {service.title}
                      </Link>
                    ))}
                  </div>
                )}
              </div>

              {/* Products Dropdown */}
              <div className="relative">
                <button
                  className={`flex items-center gap-1 text-lg font-medium text-gray-700 hover:text-primary transition-colors relative pb-1 ${
                    pathname.startsWith('/products')
                      ? "after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-red-600"
                      : ""
                  }`}
                  onClick={() => handleDropdownToggle('products')}
                  onMouseEnter={() => setActiveDropdown('products')}
                >
                  Products
                  <ChevronDown className="h-4 w-4" />
                </button>
                
                {activeDropdown === 'products' && (
                  <div 
                    className="absolute top-full left-0 mt-1 w-80 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50 max-h-96 overflow-y-auto"
                    onMouseLeave={() => setActiveDropdown(null)}
                  >
                    <Link
                      href="/products"
                      className="block px-4 py-2 text-gray-700 hover:bg-gray-50 hover:text-primary transition-colors font-medium"
                      onClick={closeDropdowns}
                    >
                      All Products
                    </Link>
                    <hr className="my-2" />
                    
                    {categories.map((category) => {
                      const categorySubcategories = getSubcategoriesForCategory(category.id)
                      const isExpanded = expandedCategories.has(category.id)
                      
                      return (
                        <div key={category.id}>
                          {categorySubcategories.length > 0 ? (
                            // Category with subcategories - clickable to expand/collapse
                            <>
                              <div 
                                className="flex items-center justify-between px-4 py-2 text-gray-700 hover:bg-gray-50 cursor-pointer transition-colors group"
                                onClick={(e) => handleCategoryToggle(category.id, e)}
                                onDoubleClick={(e) => handleCategoryNavigation(category.slug, e)}
                                title="Click to expand/collapse • Double-click to visit category page"
                              >
                                <span className="flex-1 font-medium group-hover:text-primary">
                                  {category.name}
                                </span>
                                {isExpanded ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                              </div>
                              
                              {/* Subcategories - shown when expanded */}
                              {isExpanded && (
                                <div className="ml-4 border-l border-gray-200 pl-2">
                                  {categorySubcategories.map((subcategory) => (
                                    <Link
                                      key={subcategory.id}
                                      href={`/products/category/${category.slug}/${subcategory.slug}`}
                                      className="block px-4 py-2 text-gray-600 hover:bg-gray-50 hover:text-primary transition-colors text-sm"
                                      onClick={closeDropdowns}
                                    >
                                      {subcategory.name}
                                    </Link>
                                  ))}
                                </div>
                              )}
                            </>
                          ) : (
                            // Category without subcategories - direct link
                            <Link
                              href={`/products?category=${category.slug}`}
                              className="block px-4 py-2 text-gray-700 hover:bg-gray-50 hover:text-primary transition-colors font-medium"
                              onClick={closeDropdowns}
                            >
                              {category.name}
                            </Link>
                          )}
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>

              <Link
                href="/contact"
                className={`text-lg font-medium text-gray-700 hover:text-primary transition-colors relative pb-1 ${
                  pathname === '/contact'
                    ? "after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-red-600"
                    : ""
                }`}
                onClick={closeDropdowns}
              >
                Contact Us
              </Link>

              <button
                onClick={() => setIsEnquiryModalOpen(true)}
                className="px-6 py-2.5 text-white font-medium rounded-full transition-colors"
                style={{ backgroundColor: "#4384C5" }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#ef4444")}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#4384C5")}
              >
                Enquiry Now
              </button>
            </div>

            {/* Mobile menu button */}
            <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 space-y-2 border-t">
              {baseNavigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`block py-2 text-lg font-medium text-gray-700 hover:text-primary transition-colors ${
                      isActive ? "text-red-600 font-semibold" : ""
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                )
              })}
              
              {/* Mobile Services */}
              <div>
                <Link
                  href="/services"
                  className={`block py-2 text-lg font-medium text-gray-700 hover:text-primary transition-colors ${
                    pathname.startsWith('/services') ? "text-red-600 font-semibold" : ""
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Services
                </Link>
                <div className="ml-4 space-y-1">
                  {services.map((service) => (
                    <Link
                      key={service.id}
                      href={`/services#${service.slug}`}
                      className="block py-1 text-sm text-gray-600 hover:text-primary transition-colors"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {service.title}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Mobile Products */}
              <div>
                <Link
                  href="/products"
                  className={`block py-2 text-lg font-medium text-gray-700 hover:text-primary transition-colors ${
                    pathname.startsWith('/products') ? "text-red-600 font-semibold" : ""
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Products
                </Link>
                <div className="ml-4 space-y-1">
                  {categories.map((category) => {
                    const categorySubcategories = getSubcategoriesForCategory(category.id)
                    return (
                      <div key={category.id}>
                        <Link
                          href={`/products?category=${category.slug}`}
                          className="block py-1 text-sm text-gray-600 hover:text-primary transition-colors font-medium"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          {category.name}
                        </Link>
                        <div className="ml-4 space-y-1">
                          {categorySubcategories.map((subcategory) => (
                            <Link
                              key={subcategory.id}
                              href={`/products/category/${category.slug}/${subcategory.slug}`}
                              className="block py-1 text-xs text-gray-500 hover:text-primary transition-colors"
                              onClick={() => setMobileMenuOpen(false)}
                            >
                              {subcategory.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>

              <Link
                href="/contact"
                className={`block py-2 text-lg font-medium text-gray-700 hover:text-primary transition-colors ${
                  pathname === '/contact' ? "text-red-600 font-semibold" : ""
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Contact Us
              </Link>

              <button
                onClick={() => {
                  setIsEnquiryModalOpen(true)
                  setMobileMenuOpen(false)
                }}
                className="w-full px-6 py-2.5 text-white font-medium rounded-full transition-colors mt-4"
                style={{ backgroundColor: "#4384C5" }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#ef4444")}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#4384C5")}
              >
                Enquiry Now
              </button>
            </div>
          )}
        </nav>
      </header>

      {/* EnquiryModal component */}
      <EnquiryModal isOpen={isEnquiryModalOpen} onClose={() => setIsEnquiryModalOpen(false)} />
    </>
  )
}
