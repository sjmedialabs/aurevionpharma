import Image from "next/image"

export function VisionMission() {
  return (
    <section className="py-16 md:py-24" style={{ backgroundColor: "#053C74" }}>
      <div className="container mx-auto px-4">
        <div className="mb-12">
          <div className="inline-block px-4 py-2 rounded-full border-2 border-white/30">
            <p className="text-sm font-medium text-white uppercase tracking-wide">OUR APPROACH</p>
          </div>
        </div>

        {/* Vision Section */}
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div className="space-y-4">
            <h2
              className="font-light text-white mb-6"
              style={{
                fontFamily: "Poppins, sans-serif",
                fontSize: "36px",
                fontWeight: 300,
                lineHeight: "1.3",
              }}
            >
              STRATEGIC PROCESS BACKED
              <br />
              BY PROVEN SCIENCE
            </h2>
            <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">OUR VISION</h3>
            <p
              className="text-white/90 leading-relaxed"
              style={{ fontFamily: "Poppins, sans-serif", fontSize: "15px" }}
            >
              To be a globally respected leader in the pharmaceutical and chemical service providing sector, recognized
              for excellence, reliability, and innovation. We strive to continuously enhance our products and services
              while upholding our core values of integrity, quality, and sustainable growth.
            </p>
          </div>
          <div className="relative rounded-2xl overflow-hidden shadow-xl">
            <Image
              src="/images/vision-holographic.png"
              alt="Vision concept with hexagonal business icons"
              width={600}
              height={400}
              className="w-full h-auto"
            />
          </div>
        </div>

        {/* Mission Section */}
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative rounded-2xl overflow-hidden shadow-xl order-2 md:order-1">
            <Image
              src="/images/compass-mission.png"
              alt="Mission concept with compass"
              width={600}
              height={400}
              className="w-full h-auto"
            />
          </div>
          <div className="space-y-4 order-1 md:order-2">
            <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">OUR MISSION</h3>
            <div className="space-y-4">
              <p
                className="text-white/90 leading-relaxed"
                style={{ fontFamily: "Poppins, sans-serif", fontSize: "15px" }}
              >
                Our mission is to deliver high-quality pharmaceutical and chemical supplies & services with precision,
                efficiency, and reliability. We are committed to creating tangible value for our customers, partners,
                and communities by integrating sustainable business practices across all operations.
              </p>
              <p
                className="text-white/90 leading-relaxed"
                style={{ fontFamily: "Poppins, sans-serif", fontSize: "15px" }}
              >
                We uphold the highest standards of accountability and responsibility, ensuring that our business
                practices respect our employees, customers, suppliers, and the environment. Every product we provide and
                every interaction we have reflects our dedication to quality, trust, and long-term partnerships.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
