import Image from "next/image"

export function AboutHero() {
  return (
    <section className="relative w-full h-[400px] md:h-[500px]">
      <Image src="/images/about-hero.png" alt="Aurevion Pharmaceutical Campus" fill className="object-cover" priority />
    </section>
  )
}
