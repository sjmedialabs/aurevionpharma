"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Search, Package } from "lucide-react"
import type { Product, Category, SubCategory } from "@/types"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useToastContext } from "@/components/providers/toast-provider"
import { AccordionItem } from "@/components/admin/accordion-item"
import { Badge } from "@/components/ui/badge"

export default function AdminProductsPage() {
  const { success, error } = useToastContext()
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [subcategories, setSubcategories] = useState<SubCategory[]>([])
  const [filteredSubcategories, setFilteredSubcategories] = useState<SubCategory[]>([])
  const [search, setSearch] = useState("")
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  
  const [formData, setFormData] = useState({
    name: "",
    casNumber: "",
    description: "",
    category: "",
    subcategory: "",
    molecularFormula: "",
    molecularWeight: "",
    inStock: true,
  })

  useEffect(() => {
    fetchProducts()
    fetchCategories()
    fetchSubcategories()
  }, [])

  useEffect(() => {
    if (formData.category) {
      const filtered = subcategories.filter(sub => sub.categoryId === formData.category)
      setFilteredSubcategories(filtered)
    } else {
      setFilteredSubcategories([])
    }
  }, [formData.category, subcategories])

  const fetchProducts = async () => {
    try {
      const response = await fetch("/api/admin/products")
      const data = await response.json()
      setProducts(data)
    } catch (error) {
      console.error("Failed to fetch products:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const response = await fetch("/api/admin/categories")
      const data = await response.json()
      setCategories(data)
    } catch (error) {
      console.error("Failed to fetch categories:", error)
    }
  }

  const fetchSubcategories = async () => {
    try {
      const response = await fetch("/api/admin/subcategories")
      const data = await response.json()
      setSubcategories(data)
    } catch (error) {
      console.error("Failed to fetch subcategories:", error)
    }
  }

  const handleCreateProduct = () => {
    setEditingProduct(null)
    setFormData({
      name: "",
      casNumber: "",
      description: "",
      category: "",
      subcategory: "",
      molecularFormula: "",
      molecularWeight: "",
      inStock: true,
    })
    setDialogOpen(true)
  }

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product)
    setFormData({
      name: product.name,
      casNumber: product.casNumber,
      description: product.description,
      category: product.categoryId,
      subcategory: product.subcategoryId,
      molecularFormula: product.molecularFormula || "",
      molecularWeight: product.molecularWeight || "",
      inStock: product.inStock,
    })
    setDialogOpen(true)
  }

  const handleSaveProduct = async () => {
    if (!formData.name || !formData.casNumber || !formData.description || !formData.category) {
      error("Please fill in all required fields")
      return
    }

    setSaving(true)
    try {
      const method = editingProduct ? "PUT" : "POST"
      const url = editingProduct ? `/api/admin/products/${editingProduct.id}` : "/api/admin/products"
      
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          casNumber: formData.casNumber,
          description: formData.description,
          categoryId: formData.category,
          subcategoryId: formData.subcategory || null,
          molecularFormula: formData.molecularFormula || null,
          molecularWeight: formData.molecularWeight || null,
          inStock: formData.inStock,
        }),
      })

      if (!response.ok) throw new Error("Failed to save product")

      success(editingProduct ? "Product updated successfully" : "Product created successfully")
      setDialogOpen(false)
      fetchProducts()
    } catch (err) {
      error("Failed to save product")
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm("Are you sure you want to delete this product?")) return

    try {
      const response = await fetch(`/api/admin/products/${productId}`, {
        method: "DELETE",
      })

      if (!response.ok) throw new Error("Failed to delete product")

      success("Product deleted successfully")
      fetchProducts()
    } catch (err) {
      error("Failed to delete product")
    }
  }

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(search.toLowerCase()) ||
    product.casNumber.toLowerCase().includes(search.toLowerCase()) ||
    product.category.toLowerCase().includes(search.toLowerCase())
  )

  const getCategoryName = (categoryId: string) => {
    return categories.find(cat => cat.id === categoryId)?.name || "Unknown"
  }

  const getSubcategoryName = (subcategoryId: string) => {
    return subcategories.find(sub => sub.id === subcategoryId)?.name || ""
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Products</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Manage pharmaceutical products and APIs
            </p>
          </div>
          <Button onClick={handleCreateProduct} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add Product
          </Button>
        </div>

        <div className="flex items-center gap-4 mb-6">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
            <Package className="h-4 w-4" />
            {filteredProducts.length} products
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="text-gray-500 dark:text-gray-400">Loading products...</div>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredProducts.length === 0 ? (
            <Card className="p-12 text-center dark:bg-gray-800 dark:border-gray-700">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No products found</h3>
              <p className="text-gray-600 dark:text-gray-400">
                {search ? "Try adjusting your search criteria" : "Get started by adding your first product"}
              </p>
            </Card>
          ) : (
            filteredProducts.map((product) => (
              <AccordionItem
                key={product.id}
                id={product.id}
                title={product.name}
                subtitle={`CAS: ${product.casNumber}`}
                status={{
                  label: product.inStock ? "In Stock" : "Out of Stock",
                  variant: product.inStock ? "success" : "destructive"
                }}
                summary={
                  <div className="flex items-center gap-4">
                    <span>{getCategoryName(product.categoryId)}</span>
                    {product.subcategoryId && (
                      <>
                        <span>•</span>
                        <span>{getSubcategoryName(product.subcategoryId)}</span>
                      </>
                    )}
                    {product.molecularFormula && (
                      <>
                        <span>•</span>
                        <span className="font-mono text-xs">{product.molecularFormula}</span>
                      </>
                    )}
                  </div>
                }
                details={
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white mb-2">Description</h4>
                      <p className="text-gray-700 dark:text-gray-300">{product.description}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <h5 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Category</h5>
                        <p className="text-sm text-gray-900 dark:text-white">{getCategoryName(product.categoryId)}</p>
                      </div>
                      
                      {product.subcategoryId && (
                        <div>
                          <h5 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Subcategory</h5>
                          <p className="text-sm text-gray-900 dark:text-white">{getSubcategoryName(product.subcategoryId)}</p>
                        </div>
                      )}
                      
                      {product.molecularFormula && (
                        <div>
                          <h5 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Molecular Formula</h5>
                          <p className="text-sm font-mono text-gray-900 dark:text-white">{product.molecularFormula}</p>
                        </div>
                      )}
                      
                      {product.molecularWeight && (
                        <div>
                          <h5 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Molecular Weight</h5>
                          <p className="text-sm text-gray-900 dark:text-white">{product.molecularWeight}</p>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-gray-200 dark:border-gray-700">
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        Created: {new Date(product.createdAt).toLocaleDateString()}
                        {product.updatedAt && product.updatedAt !== product.createdAt && (
                          <span className="ml-4">Updated: {new Date(product.updatedAt).toLocaleDateString()}</span>
                        )}
                      </div>
                      <Badge variant={product.inStock ? "success" : "destructive"}>
                        {product.inStock ? "Available" : "Out of Stock"}
                      </Badge>
                    </div>
                  </div>
                }
                onEdit={() => handleEditProduct(product)}
                onDelete={() => handleDeleteProduct(product.id)}
              />
            ))
          )}
        </div>
      )}

      {/* Create/Edit Product Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingProduct ? "Edit Product" : "Create New Product"}</DialogTitle>
            <DialogDescription>
              {editingProduct ? "Update the product information below." : "Add a new pharmaceutical product to your inventory."}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Product Name*</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter product name"
                />
              </div>
              
              <div>
                <Label htmlFor="casNumber">CAS Number*</Label>
                <Input
                  id="casNumber"
                  value={formData.casNumber}
                  onChange={(e) => setFormData({ ...formData, casNumber: e.target.value })}
                  placeholder="Enter CAS number"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Category*</Label>
                <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value, subcategory: "" })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="subcategory">Subcategory</Label>
                <Select value={formData.subcategory} onValueChange={(value) => setFormData({ ...formData, subcategory: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select subcategory" />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredSubcategories.map((subcategory) => (
                      <SelectItem key={subcategory.id} value={subcategory.id}>
                        {subcategory.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="molecularFormula">Molecular Formula</Label>
                <Input
                  id="molecularFormula"
                  value={formData.molecularFormula}
                  onChange={(e) => setFormData({ ...formData, molecularFormula: e.target.value })}
                  placeholder="e.g., C8H9NO2"
                />
              </div>

              <div>
                <Label htmlFor="molecularWeight">Molecular Weight</Label>
                <Input
                  id="molecularWeight"
                  value={formData.molecularWeight}
                  onChange={(e) => setFormData({ ...formData, molecularWeight: e.target.value })}
                  placeholder="e.g., 151.16"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="description">Description*</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Enter product description"
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="inStock"
                checked={formData.inStock}
                onCheckedChange={(checked) => setFormData({ ...formData, inStock: checked as boolean })}
              />
              <Label htmlFor="inStock">In Stock</Label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveProduct} disabled={saving}>
              {saving ? "Saving..." : editingProduct ? "Update Product" : "Create Product"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
