import { NextRequest, NextResponse } from "next/server"
import { getRepository } from "@/lib/repo"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const subcategory = searchParams.get("subcategory")
    const search = searchParams.get("search")
    const inStock = searchParams.get("inStock")
    const sort = searchParams.get("sort")

    const repository = getRepository()
    
    // If no filters, return all products
    if (!category && !subcategory && !search && !inStock && !sort) {
      const products = await repository.getAllProducts()
      return NextResponse.json(products)
    }

    // Build query filters
    const filters: any = {}
    
    if (category) {
      filters.category = category
    }
    
    if (subcategory) {
      filters.subcategory = subcategory
    }
    
    if (inStock === "true") {
      filters.inStock = true
    } else if (inStock === "false") {
      filters.inStock = false
    }

    // Get filtered products
    const products = await repository.getFilteredProducts(filters, search, sort)
    return NextResponse.json(products)
  } catch (error) {
    console.error("Failed to fetch products:", error)
    return NextResponse.json({ error: "Failed to fetch products" }, { status: 500 })
  }
}
