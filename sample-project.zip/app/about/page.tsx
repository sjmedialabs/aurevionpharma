import type { Metadata } from "next"
import { generateSEOMetadata } from "@/lib/seo"
import { Header } from "@/components/common/header"
import { Footer } from "@/components/common/footer"
import { WhatsAppButton } from "@/components/common/whatsapp-button"
import { AboutHero } from "@/components/about/about-hero"
import { AboutIntro } from "@/components/about/about-intro"
import { VisionMission } from "@/components/about/vision-mission"
import { WhyLabrix } from "@/components/about/why-labrix"

export const metadata: Metadata = generateSEOMetadata({
  title: "About Us",
  description:
    "Learn about Aurevion Pharmatech's 16-year journey in pharmaceutical innovation. Discover our mission, vision, values, and commitment to quality in drug discovery.",
  path: "/about",
})

export default function AboutPage() {
  return (
    <>
      <Header />
      <main>
        <AboutHero />
        <AboutIntro />
        <VisionMission />
        <WhyLabrix />
      </main>
      <Footer />
      <WhatsAppButton />
    </>
  )
}
