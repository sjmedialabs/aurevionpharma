import type { Metadata } from "next"
import { generateSEOMetadata, generateBreadcrumbStructuredData } from "@/lib/seo"
import { StructuredData } from "@/components/common/structured-data"
import { Header } from "@/components/common/header"
import { Footer } from "@/components/common/footer"
import { WhatsAppButton } from "@/components/common/whatsapp-button"
import { ProductsHero } from "@/components/products/products-hero"
import { ProductsGrid } from "@/components/products/products-grid"
import { getRepository } from "@/lib/repo"

export const dynamic = 'force-dynamic'
export const revalidate = 0

export const metadata: Metadata = generateSEOMetadata({
  title: "Products",
  description:
    "Browse our comprehensive catalog of high-quality Active Pharmaceutical Ingredients (APIs) for global pharma needs. Search by CAS number, HS code, or category.",
  path: "/products",
})

export default async function ProductsPage() {
  const breadcrumbs = generateBreadcrumbStructuredData([
    { name: "Home", url: "/" },
    { name: "Products", url: "/products" },
  ])

  const repo = getRepository()
  const products = await repo.getAllProducts()
  const categories = await repo.getAllCategories()

  return (
    <>
      <StructuredData data={breadcrumbs} />
      <Header />
      <main>
        <ProductsHero />
        <ProductsGrid products={products} categories={categories} />
      </main>
      <Footer />
      <WhatsAppButton />
    </>
  )
}
