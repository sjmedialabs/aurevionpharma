import type { Metadata } from "next"
import { generateSEOMetadata } from "@/lib/seo"
import { Header } from "@/components/common/header"
import { Footer } from "@/components/common/footer"
import { ContactHero } from "@/components/contact/contact-hero"
import { ContactForm } from "@/components/contact/contact-form"
import { ContactInfo } from "@/components/contact/contact-info"
import { WhatsAppButton } from "@/components/common/whatsapp-button"

export const metadata: Metadata = generateSEOMetadata({
  title: "Contact Us",
  description:
    "Get in touch with Aurevion Pharmatech for product enquiries, bulk orders, or general inquiries. Our team is ready to assist with your pharmaceutical needs.",
  path: "/contact",
})

export default function ContactPage() {
  return (
    <>
      <Header />
      <main>
        <ContactHero />

        <section className="bg-gray-50 py-16">
          <div className="container mx-auto max-w-7xl px-4 md:px-6 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
              {/* Left Column - Contact Form */}
              <ContactForm />

              {/* Right Column - Contact Info */}
              <ContactInfo />
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <WhatsAppButton />
    </>
  )
}
