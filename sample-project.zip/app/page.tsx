import type { Metadata } from "next"
import { HeroSection } from "@/components/client/hero-section"
import { StatsSection } from "@/components/client/stats-section"
import { AboutPreview } from "@/components/client/about-preview"
import { ServicesPreview } from "@/components/client/services-preview"
import { ProductsPreview } from "@/components/client/products-preview"
import { ProcessSection } from "@/components/client/process-section"
import { Header } from "@/components/common/header"
import { Footer } from "@/components/common/footer"
import { WhatsAppButton } from "@/components/common/whatsapp-button"
import { generateSEOMetadata } from "@/lib/seo"

export const dynamic = 'force-dynamic'
export const revalidate = 0

export const metadata: Metadata = generateSEOMetadata({
  title: "Home",
  description:
    "Aurevion Pharmatech - Leading pharmaceutical company specializing in high-quality APIs, CMO, CDMO, and partnering services. Driven by care, guided by trust.",
  path: "/",
})

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <StatsSection />
        <AboutPreview />
        <ServicesPreview />
        <ProductsPreview />
        <ProcessSection />
      </main>
      <Footer />
      <WhatsAppButton />
    </>
  )
}
